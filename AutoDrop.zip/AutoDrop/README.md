# Auto Drop (Android)

Floating menu + Accessibility Service jo Yalla ke chat box mein text bhej kar Send dabata hai.

## Build (GitHub Actions)
1. Ye saari files apni GitHub repo mein upload karein (".github" folder samet).
2. Repo > Actions > "Build APK" > Run workflow (ya push par khud chalega).
3. Run khatam hone par neeche "Artifacts" se AutoDrop-APK download karein.
