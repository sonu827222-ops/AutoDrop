package com.autodrop.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;
import java.util.Random;

public class AutoService extends AccessibilityService {

    public static AutoService inst;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();

    private final Runnable loop = new Runnable() {
        @Override
        public void run() {
            if (!Cfg.running) return;
            try {
                step();
            } catch (Exception ignored) {
            }
            h.postDelayed(this, Math.max(50, Cfg.delayMs));
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        inst = this;
        Cfg.load(this);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override
    public void onInterrupt() { }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        inst = null;
        Cfg.running = false;
        return super.onUnbind(intent);
    }

    public void startLoop() {
        h.removeCallbacks(loop);
        h.post(loop);
    }

    private String gen() {
        String set = Cfg.digits ? "0123456789" : "abcdefghijklmnopqrstuvwxyz";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Cfg.length; i++) sb.append(set.charAt(rnd.nextInt(set.length())));
        return sb.toString();
    }

    private void step() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        CharSequence pkg = root.getPackageName();
        if (pkg == null || !pkg.toString().toLowerCase().contains("yalla")) return;

        AccessibilityNodeInfo input = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (input == null || !input.isEditable()) input = findEditable(root);
        if (input == null) return;

        Bundle b = new Bundle();
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, gen());
        input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b);

        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                pressSend();
            }
        }, 40);
    }

    private void pressSend() {
        if (Cfg.sendX >= 0 && Cfg.sendY >= 0) {
            tap(Cfg.sendX, Cfg.sendY);
            return;
        }
        // fallback: find a node called "send"
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByText("send");
        for (AccessibilityNodeInfo n : nodes) {
            AccessibilityNodeInfo c = n;
            while (c != null && !c.isClickable()) c = c.getParent();
            if (c != null) {
                c.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                return;
            }
        }
    }

    private AccessibilityNodeInfo findEditable(AccessibilityNodeInfo n) {
        if (n == null) return null;
        if (n.isEditable() && n.isVisibleToUser()) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = findEditable(n.getChild(i));
            if (r != null) return r;
        }
        return null;
    }

    private void tap(float x, float y) {
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription.Builder gb = new GestureDescription.Builder();
        gb.addStroke(new GestureDescription.StrokeDescription(p, 0, 30));
        dispatchGesture(gb.build(), null, null);
    }
}
