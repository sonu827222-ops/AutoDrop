package com.autodrop.app;

import android.content.Context;
import android.content.SharedPreferences;

public class Cfg {
    public static volatile int length = 1;        // 1..4 characters per message
    public static volatile boolean digits = true; // true = numbers, false = alphabets
    public static volatile int delayMs = 300;     // gap between messages
    public static volatile float sendX = -1f;
    public static volatile float sendY = -1f;
    public static volatile boolean running = false;

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("cfg", Context.MODE_PRIVATE);
    }

    public static void load(Context c) {
        SharedPreferences p = sp(c);
        length = p.getInt("length", 1);
        digits = p.getBoolean("digits", true);
        delayMs = p.getInt("delay", 300);
        sendX = p.getFloat("sx", -1f);
        sendY = p.getFloat("sy", -1f);
    }

    public static void save(Context c) {
        sp(c).edit()
                .putInt("length", length)
                .putBoolean("digits", digits)
                .putInt("delay", delayMs)
                .putFloat("sx", sendX)
                .putFloat("sy", sendY)
                .apply();
    }
}
