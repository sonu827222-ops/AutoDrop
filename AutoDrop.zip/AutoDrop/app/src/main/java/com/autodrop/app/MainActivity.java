package com.autodrop.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private TextView status;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private Button btn(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        Cfg.load(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(40), dp(20), dp(20));

        TextView title = new TextView(this);
        title.setText("Auto Drop");
        title.setTextSize(26);
        title.setTextColor(Color.parseColor("#6A1B9A"));
        root.addView(title);

        status = new TextView(this);
        status.setTextSize(15);
        status.setPadding(0, dp(12), 0, dp(12));
        root.addView(status);

        root.addView(btn("1) Overlay permission do", new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            }
        }));

        root.addView(btn("2) Accessibility ON karo", new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                Toast.makeText(MainActivity.this, "Installed apps > Auto Drop > ON", Toast.LENGTH_LONG).show();
            }
        }));

        root.addView(btn("3) Floating menu start", new View.OnClickListener() {
            public void onClick(View v) {
                if (!Settings.canDrawOverlays(MainActivity.this)) {
                    Toast.makeText(MainActivity.this, "Pehle overlay permission do", Toast.LENGTH_LONG).show();
                    return;
                }
                startService(new Intent(MainActivity.this, OverlayService.class));
                Toast.makeText(MainActivity.this, "Ab Yalla Ludo kholo, ⚡ button dikhega", Toast.LENGTH_LONG).show();
            }
        }));

        root.addView(btn("Floating menu band", new View.OnClickListener() {
            public void onClick(View v) {
                Cfg.running = false;
                stopService(new Intent(MainActivity.this, OverlayService.class));
            }
        }));

        TextView note = new TextView(this);
        note.setText("\nAndroid 13+ par Accessibility grey ho to: Settings > Apps > Auto Drop > "
                + "teen dots (⋮) > \"Allow restricted settings\", phir dobara Accessibility ON karein.");
        note.setTextSize(13);
        root.addView(note);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean ov = Settings.canDrawOverlays(this);
        boolean acc = AutoService.inst != null;
        status.setText("Overlay permission: " + (ov ? "OK ✅" : "Nahi ❌")
                + "\nAccessibility: " + (acc ? "ON ✅" : "OFF ❌"));
    }
}
