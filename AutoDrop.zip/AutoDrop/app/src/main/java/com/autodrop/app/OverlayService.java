package com.autodrop.app;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class OverlayService extends Service {

    private WindowManager wm;
    private LinearLayout root;
    private LinearLayout panel;
    private WindowManager.LayoutParams lp;
    private View capture;
    private Button startStop;

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private int type() {
        return Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private Button btn(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private TextView label(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(Color.WHITE);
        v.setTextSize(12);
        v.setPadding(0, dp(6), 0, dp(2));
        return v;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Cfg.load(this);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        build();
    }

    private void build() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        // floating bubble
        final TextView bubble = new TextView(this);
        bubble.setText("⚡");
        bubble.setTextSize(22);
        bubble.setGravity(Gravity.CENTER);
        bubble.setTextColor(Color.WHITE);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0xFF6A1B9A);
        bubble.setBackground(bg);
        root.addView(bubble, new LinearLayout.LayoutParams(dp(48), dp(48)));

        // menu panel
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(10), dp(8), dp(10), dp(10));
        GradientDrawable pbg = new GradientDrawable();
        pbg.setCornerRadius(dp(12));
        pbg.setColor(0xEE1E1E2E);
        panel.setBackground(pbg);
        panel.setVisibility(View.GONE);
        root.addView(panel, new LinearLayout.LayoutParams(dp(230), LinearLayout.LayoutParams.WRAP_CONTENT));

        panel.addView(label("AUTO SEND (kitne alphabet/number)"));
        String[] names = {"ONE", "TWO", "THREE", "FOUR"};
        RadioGroup rg = new RadioGroup(this);
        rg.setOrientation(RadioGroup.VERTICAL);
        for (int n = 1; n <= 4; n++) {
            RadioButton rb = new RadioButton(this);
            rb.setText("Auto Send " + n + " - " + names[n - 1] + " alphabet");
            rb.setTextColor(Color.WHITE);
            rb.setTextSize(12);
            rb.setId(100 + n);
            rg.addView(rb);
        }
        rg.check(100 + Cfg.length);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup g, int id) {
                Cfg.length = id - 100;
                Cfg.save(OverlayService.this);
            }
        });
        panel.addView(rg);

        CheckBox cb = new CheckBox(this);
        cb.setText("Numbers (off = alphabets)");
        cb.setTextColor(Color.WHITE);
        cb.setTextSize(12);
        cb.setChecked(Cfg.digits);
        cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean c) {
                Cfg.digits = c;
                Cfg.save(OverlayService.this);
            }
        });
        panel.addView(cb);

        // speed
        final TextView speedLbl = label("");
        panel.addView(speedLbl);
        SeekBar sb = new SeekBar(this);
        sb.setMax(19);
        int prog = Math.max(0, Math.min(19, (1000 - Cfg.delayMs) / 50));
        sb.setProgress(prog);
        speedLbl.setText("SPEED BOOST  (delay " + Cfg.delayMs + " ms)");
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                Cfg.delayMs = 1000 - p * 50;
                speedLbl.setText("SPEED BOOST  (delay " + Cfg.delayMs + " ms)");
            }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) {
                Cfg.save(OverlayService.this);
            }
        });
        panel.addView(sb);

        panel.addView(btn("Set Send Position", new View.OnClickListener() {
            public void onClick(View v) {
                pickPosition();
            }
        }));

        startStop = btn("▶ Start Auto Sender", new View.OnClickListener() {
            public void onClick(View v) {
                toggleRun();
            }
        });
        panel.addView(startStop);

        panel.addView(btn("Close menu", new View.OnClickListener() {
            public void onClick(View v) {
                Cfg.running = false;
                stopSelf();
            }
        }));

        lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        lp.x = dp(8);
        lp.y = dp(120);

        bubble.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;
            boolean moved;

            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = lp.x; sy = lp.y;
                        tx = e.getRawX(); ty = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (e.getRawX() - tx);
                        int dy = (int) (e.getRawY() - ty);
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true;
                        if (moved) {
                            lp.x = sx + dx;
                            lp.y = sy + dy;
                            wm.updateViewLayout(root, lp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) {
                            panel.setVisibility(panel.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
                        }
                        return true;
                }
                return false;
            }
        });

        wm.addView(root, lp);
    }

    private void toggleRun() {
        if (Cfg.running) {
            Cfg.running = false;
            startStop.setText("▶ Start Auto Sender");
            return;
        }
        if (AutoService.inst == null) {
            Toast.makeText(this, "Accessibility service ON karein", Toast.LENGTH_LONG).show();
            return;
        }
        if (Cfg.sendX < 0) {
            Toast.makeText(this, "Pehle 'Set Send Position' karein", Toast.LENGTH_LONG).show();
            return;
        }
        Cfg.running = true;
        startStop.setText("■ Stop Auto Sender");
        AutoService.inst.startLoop();
    }

    private void pickPosition() {
        panel.setVisibility(View.GONE);
        TextView t = new TextView(this);
        t.setText("Yalla ke SEND button par ek baar tap karein");
        t.setGravity(Gravity.CENTER);
        t.setTextColor(Color.WHITE);
        t.setTextSize(18);
        t.setBackgroundColor(0x66000000);
        capture = t;
        t.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    Cfg.sendX = e.getRawX();
                    Cfg.sendY = e.getRawY();
                    Cfg.save(OverlayService.this);
                    try {
                        wm.removeView(capture);
                    } catch (Exception ignored) {
                    }
                    capture = null;
                    Toast.makeText(OverlayService.this, "Send position save ho gayi ✅", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        wm.addView(t, p);
    }

    @Override
    public void onDestroy() {
        Cfg.running = false;
        try {
            if (root != null) wm.removeView(root);
            if (capture != null) wm.removeView(capture);
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }
}
